import 'package:flutter/material.dart';
import 'package:wallet1/color.dart';
import 'package:wallet1/home.dart';
import 'package:wallet1/theme.dart';
import 'package:wallet1/widgets/login_form.dart';
import 'package:wallet1/widgets/login_option.dart';
import 'package:wallet1/widgets/primary_button.dart';

class Loginn extends StatelessWidget {
  const Loginn({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: kDefaultPadding,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 120,
              ),
              Text(
                'CRYFIM',
                style: titleText,
              ),
              const SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  Text(
                    'Manage all your funds',
                    style: subTitle,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Wallet(),
                        ),
                      );
                    },
                    child: Text(
                      '',
                      style: textButton.copyWith(
                        decoration: TextDecoration.underline,
                        decorationThickness: 1,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              LogInForm(),
              const SizedBox(
                height: 20,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Wallet()));
                },
                child: const Text(
                  '',
                  style: TextStyle(
                    color: kZambeziColor,
                    fontSize: 14,
                    decoration: TextDecoration.underline,
                    decorationThickness: 1,
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              PrimaryButton(
                buttonText: 'Login',
              ),
              PrimaryButton(
                buttonText: 'CREAT ACCOUNT',
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                '',
                style: subTitle.copyWith(color: HexColor("232B2E")),
              ),
              const SizedBox(
                height: 20,
              ),
              LoginOption(),
            ],
          ),
        ),
      ),
    );
  }
}